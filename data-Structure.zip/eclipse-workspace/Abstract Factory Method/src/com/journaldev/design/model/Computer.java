
package com.journaldev.design.model;
 
public abstract class Computer {
     //This abstract class is extended by PC and Server 
    public abstract String getRAM();
    public abstract String getHDD();
    public abstract String getCPU();
     
    @Override
    public String toString(){
        return "RAM= "+this.getRAM()+", HDD="+this.getHDD()+", CPU="+this.getCPU();
    }
}
